package com.beeassist.app.core

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.SystemClock
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.beeassist.app.data.*
import kotlinx.coroutines.*
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Menjalankan rangkaian langkah:
 *   TTS -> aplikasi -> TTS -> aplikasi -> TTS ...
 * Setelah tiap TTS (kecuali yang terakhir) mendengarkan perintah suara:
 *   "lanjut", "lewati", "ulangi", "berhenti".
 */
class RunnerService : Service() {
    companion object { const val ACTION_STOP = "com.beeassist.app.STOP" }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var tts: TextToSpeech? = null
    private var wake: PowerManager.WakeLock? = null
    private var focus: AudioFocusRequest? = null
    private var micOk = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            job?.cancel()
            if (job == null) stopSelf()
            return START_NOT_STICKY
        }
        micOk = startFg()
        if (job?.isActive == true) return START_NOT_STICKY

        val id = intent?.getLongExtra(Scheduler.EXTRA_ID, -1) ?: -1
        val iter = intent?.getIntExtra(Scheduler.EXTRA_ITER, 1) ?: 1

        job = scope.launch {
            val s = withContext(Dispatchers.IO) { AppDb.get(this@RunnerService).dao().get(id) }
            if (s == null || !s.enabled) { stopSelf(); return@launch }
            var done = false
            try {
                acquireWake(s)
                if (Unlock.needed(this@RunnerService)) { Unlock.request(this@RunnerService); delay(2500) }
                tts = initTts()
                runSteps(s)
                done = true
            } finally {
                withContext(NonCancellable) {
                    if (done && iter < s.repeatCount) Scheduler.scheduleRepeat(this@RunnerService, s, iter + 1)
                    else Scheduler.scheduleNext(this@RunnerService, s)
                    cleanup()
                }
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    // ---------- alur utama ----------
    private suspend fun runSteps(s: Schedule) {
        val steps = s.steps
        val weather = if (steps.any { it.type == StepType.SPEAK && WeatherClient.needs(it.text) })
            WeatherClient.fetch(this) else null

        var i = 0
        var lastApp = -1
        while (i < steps.size) {
            val st = steps[i]
            if (st.type == StepType.SPEAK) {
                speak(WeatherClient.fill(this, st.text, weather))
                if (s.voiceControl && micOk && i < steps.size - 1) {
                    delay(400)
                    when (Voice.parse(Voice.listen(this, 6000))) {
                        Cmd.STOP -> return
                        Cmd.SKIP -> i++                                   // lewati langkah berikutnya
                        Cmd.REPEAT -> if (lastApp >= 0) { i = lastApp; continue }
                        else -> {}
                    }
                }
            } else {
                lastApp = i
                runApp(st)
            }
            i++
        }
    }

    private suspend fun runApp(st: Step) {
        if (st.type == StepType.PLAY_PLAYLIST) { playPlaylist(st); return }
        val name = st.appLabel.ifBlank { st.packageName.ifBlank { "aplikasi" } }
        if ((st.online || st.type == StepType.YOUTUBE_LATEST) && !Net.isOnline(this)) {
            speak("Tidak ada koneksi internet. $name dilewati.")
            return
        }
        var run = st
        if (st.type == StepType.YOUTUBE_LATEST) {
            val vid = YouTube.latestVideoId(st.data)
            if (vid == null) { speak("Maaf, video terbaru ${st.data} tidak ditemukan."); return }
            run = st.copy(
                type = StepType.OPEN_LINK, data = "https://www.youtube.com/watch?v=$vid",
                packageName = st.packageName.ifBlank { "com.google.android.youtube" }
            )
        }
        AppController.launch(this, run)
        try {
            delay(st.durationMin * 60_000L)
        } finally {
            withContext(NonCancellable) { AppController.stop(this@RunnerService, run) }
        }
    }

    // ---------- Pemutar playlist bawaan ----------
    private suspend fun playPlaylist(st: Step) {
        val base = PlaylistStore.get(this, st.data)
        if (base.isEmpty()) { speak("Playlist ${st.data} kosong atau tidak ditemukan."); return }
        val tracks = if (st.shuffle) base.shuffled() else base
        val end = SystemClock.elapsedRealtime() + st.durationMin * 60_000L
        var i = 0
        var fails = 0
        while (SystemClock.elapsedRealtime() < end && fails < tracks.size) {
            val t = tracks[i++ % tracks.size]
            val started = SystemClock.elapsedRealtime()
            withTimeoutOrNull(end - started) { playOne(t.uri) }
            if (SystemClock.elapsedRealtime() - started < 1500) fails++ else fails = 0
        }
    }

    private suspend fun playOne(uri: String) = suspendCancellableCoroutine<Unit> { cont ->
        val mp = MediaPlayer()
        fun done() { runCatching { mp.release() }; if (cont.isActive) cont.resume(Unit) }
        try {
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            mp.setDataSource(this, Uri.parse(uri))
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { done() }
            mp.setOnErrorListener { _, _, _ -> done(); true }
            mp.prepareAsync()
        } catch (e: Exception) { done() }
        cont.invokeOnCancellation { runCatching { mp.stop() }; runCatching { mp.release() } }
    }

    // ---------- TTS ----------
    private suspend fun initTts(): TextToSpeech? = suspendCancellableCoroutine { cont ->
        val holder = arrayOfNulls<TextToSpeech>(1)
        holder[0] = TextToSpeech(this) { status ->
            val t = holder[0]
            if (status == TextToSpeech.SUCCESS && t != null) {
                t.language = Locale("id", "ID")
                t.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                if (cont.isActive) cont.resume(t)
            } else if (cont.isActive) cont.resume(null)
        }
    }

    private suspend fun speak(text: String) {
        val t = tts ?: return
        if (text.isBlank()) return
        requestFocus()
        suspendCancellableCoroutine<Unit> { cont ->
            val uid = UUID.randomUUID().toString()
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onDone(u: String?) { if (u == uid && cont.isActive) cont.resume(Unit) }
                @Deprecated("Deprecated in Java")
                override fun onError(u: String?) { if (u == uid && cont.isActive) cont.resume(Unit) }
            })
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, uid)
            cont.invokeOnCancellation { t.stop() }
        }
        abandonFocus()
        delay(800)
    }

    // ---------- util ----------
    private fun startFg(): Boolean {
        val n = notification()
        if (Build.VERSION.SDK_INT < 30) {   // Android 10: mikrofon tidak butuh tipe khusus
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            return true
        }
        return try {
            ServiceCompat.startForeground(this, 1, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            true
        } catch (e: Exception) {   // Android 14: mic dari background / izin belum ada
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireWake(s: Schedule) {
        val total = s.steps.sumOf { if (it.type == StepType.SPEAK) 1 else it.durationMin } + 10
        wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "appsched:run"
        ).also { it.acquire(total * 60_000L) }
    }

    private fun requestFocus() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            .build().also { am.requestAudioFocus(it) }
    }

    private fun abandonFocus() {
        focus?.let { (getSystemService(AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(it) }
        focus = null
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("run", "Jadwal berjalan", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, RunnerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "run")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("App Scheduler").setContentText("Menjalankan jadwal…")
            .addAction(0, "Berhenti", stop).setOngoing(true).build()
    }

    private fun cleanup() {
        tts?.shutdown(); tts = null
        abandonFocus()
        if (wake?.isHeld == true) wake?.release()
    }

    override fun onDestroy() { scope.cancel(); cleanup(); super.onDestroy() }
}
