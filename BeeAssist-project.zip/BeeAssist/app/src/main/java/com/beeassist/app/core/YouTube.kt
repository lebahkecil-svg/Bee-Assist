package com.beeassist.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** Mencari video terbaru sebuah channel lewat RSS resmi YouTube (tanpa API key). */
object YouTube {
    private val idRegex = Regex("UC[\\w-]{22}")

    suspend fun latestVideoId(input: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val ch = channelId(input) ?: return@runCatching null
            val xml = get("https://www.youtube.com/feeds/videos.xml?channel_id=$ch")
            Regex("<yt:videoId>([^<]+)</yt:videoId>").find(xml)?.groupValues?.get(1)
        }.getOrNull()
    }

    private fun channelId(input: String): String? {
        val t = input.trim()
        if (idRegex.matches(t)) return t
        Regex("channel/(UC[\\w-]{22})").find(t)?.let { return it.groupValues[1] }
        val url = when {
            t.startsWith("http") -> t
            t.startsWith("@") -> "https://www.youtube.com/$t"
            else -> "https://www.youtube.com/@$t"
        }
        val html = get(url)
        return Regex("rel=\"canonical\" href=\"https://www.youtube.com/channel/(UC[\\w-]{22})").find(html)?.groupValues?.get(1)
            ?: Regex("\"externalId\":\"(UC[\\w-]{22})\"").find(html)?.groupValues?.get(1)
            ?: Regex("\"channelId\":\"(UC[\\w-]{22})\"").find(html)?.groupValues?.get(1)
    }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        c.setRequestProperty("Accept-Language", "id-ID,id;q=0.9")
        return c.inputStream.bufferedReader().use { it.readText() }
    }
}
