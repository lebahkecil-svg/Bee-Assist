package com.beeassist.app.ui

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.beeassist.app.core.PlaylistStore
import com.beeassist.app.data.*

fun Step.summary(): String = when (type) {
    StepType.SPEAK -> "🗣 $text"
    StepType.OPEN_APP -> "📱 ${appLabel.ifBlank { packageName }}"
    StepType.OPEN_LINK -> "🔗 ${appLabel.ifBlank { "Link" }}: $data"
    StepType.PLAY_MUSIC -> "🎵 ${appLabel.ifBlank { "Pemutar musik" }}: $data"
    StepType.YOUTUBE_LATEST -> "▶ YouTube terbaru: $data"
    StepType.PLAY_PLAYLIST -> "🎶 Playlist: $data${if (shuffle) " (acak)" else ""}"
} + if (type != StepType.SPEAK) " • $durationMin mnt • ${if (online) "online" else "offline"}" else ""

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun Editor(init: Schedule, onSave: (Schedule) -> Unit, onDelete: () -> Unit, onClose: () -> Unit) {
    var name by remember { mutableStateOf(init.name) }
    var hour by remember { mutableIntStateOf(init.hour) }
    var minute by remember { mutableIntStateOf(init.minute) }
    var days by remember { mutableIntStateOf(init.daysMask) }
    var rep by remember { mutableStateOf(init.repeatCount.toString()) }
    var gap by remember { mutableStateOf(init.repeatIntervalMin.toString()) }
    var voice by remember { mutableStateOf(init.voiceControl) }
    val steps = remember { mutableStateListOf<Step>().also { it.addAll(init.steps) } }
    var showTime by remember { mutableStateOf(false) }
    var editIdx by remember { mutableIntStateOf(-1) }     // -1 = langkah baru
    var editStep by remember { mutableStateOf<Step?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (init.id == 0L) "Jadwal baru" else "Ubah jadwal") },
                navigationIcon = { TextButton(onClick = onClose) { Text("Batal") } }
            )
        },
        bottomBar = {
            Button(
                onClick = {
                    onSave(init.copy(
                        name = name, hour = hour, minute = minute, daysMask = days, steps = steps.toList(),
                        repeatCount = rep.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                        repeatIntervalMin = gap.toIntOrNull()?.coerceAtLeast(1) ?: 5,
                        voiceControl = voice
                    ))
                },
                modifier = Modifier.fillMaxWidth().padding(12.dp).navigationBarsPadding()
            ) { Text("Simpan") }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { OutlinedTextField(name, { name = it }, label = { Text("Nama jadwal") }, modifier = Modifier.fillMaxWidth()) }
            item {
                OutlinedButton(onClick = { showTime = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Jam: %02d:%02d".format(hour, minute))
                }
            }
            item {
                Text("Hari", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DAY_NAMES.forEachIndexed { i, d ->
                        FilterChip(
                            selected = (days shr i) and 1 == 1,
                            onClick = { days = days xor (1 shl i) },
                            label = { Text(d) }
                        )
                    }
                    AssistChip(onClick = { days = 0b1111111 }, label = { Text("Semua") })
                }
            }
            item { Text("Langkah (urut dari atas)", style = MaterialTheme.typography.titleSmall) }
            itemsIndexed(steps) { i, st ->
                Card(Modifier.fillMaxWidth().clickable { editIdx = i; editStep = st }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}. ${st.summary()}", Modifier.weight(1f), maxLines = 3)
                        Column {
                            TextButton(onClick = { if (i > 0) steps.add(i - 1, steps.removeAt(i)) }) { Text("▲") }
                            TextButton(onClick = { if (i < steps.size - 1) steps.add(i + 1, steps.removeAt(i)) }) { Text("▼") }
                        }
                        TextButton(onClick = { steps.removeAt(i) }) { Text("✕") }
                    }
                }
            }
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("+ Ucapan" to StepType.SPEAK, "+ Aplikasi" to StepType.OPEN_APP,
                           "+ Link" to StepType.OPEN_LINK, "+ Musik" to StepType.PLAY_MUSIC,
                           "+ YT terbaru" to StepType.YOUTUBE_LATEST,
                           "+ Playlist" to StepType.PLAY_PLAYLIST).forEach { (l, t) ->
                        OutlinedButton(onClick = { editIdx = -1; editStep = Step(t, online = t == StepType.YOUTUBE_LATEST) }) { Text(l) }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(rep, { rep = it }, label = { Text("Ulang rangkaian") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(gap, { gap = it }, label = { Text("Jeda (mnt)") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Perintah suara")
                        Text("Dengarkan \"lanjut / lewati / ulangi / berhenti\" setelah tiap ucapan",
                            style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(voice, { voice = it })
                }
            }
            if (init.id != 0L) item { TextButton(onClick = onDelete) { Text("Hapus jadwal") } }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    if (showTime) {
        val ts = rememberTimePickerState(hour, minute, true)
        AlertDialog(
            onDismissRequest = { showTime = false },
            text = { TimeInput(ts) },
            confirmButton = { TextButton(onClick = { hour = ts.hour; minute = ts.minute; showTime = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text("Batal") } }
        )
    }

    editStep?.let { st ->
        StepDialog(st, onDismiss = { editStep = null }, onOk = { n ->
            if (editIdx >= 0) steps[editIdx] = n else steps.add(n)
            editStep = null
        })
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StepDialog(init: Step, onDismiss: () -> Unit, onOk: (Step) -> Unit) {
    var type by remember { mutableStateOf(init.type) }
    var text by remember { mutableStateOf(init.text) }
    var pkg by remember { mutableStateOf(init.packageName) }
    var label by remember { mutableStateOf(init.appLabel) }
    var data by remember { mutableStateOf(init.data) }
    var dur by remember { mutableStateOf(init.durationMin.toString()) }
    var online by remember { mutableStateOf(init.online) }
    var picker by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    var shuffle by remember { mutableStateOf(init.shuffle) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Langkah") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Ucapan" to StepType.SPEAK, "Aplikasi" to StepType.OPEN_APP,
                               "Link" to StepType.OPEN_LINK, "Musik" to StepType.PLAY_MUSIC,
                               "YT terbaru" to StepType.YOUTUBE_LATEST,
                               "Playlist" to StepType.PLAY_PLAYLIST).forEach { (l, t) ->
                            FilterChip(type == t, { type = t }, label = { Text(l) })
                        }
                    }
                }
                if (type == StepType.SPEAK) {
                    item { OutlinedTextField(text, { text = it }, label = { Text("Teks yang diucapkan") }, minLines = 3, modifier = Modifier.fillMaxWidth()) }
                    item {
                        Text("Token: {nama} {asisten} {jam} {hari} {sapaan} {cuaca} {suhu} {suhumax} {suhumin} {hujan} {angin} {lembab}",
                            style = MaterialTheme.typography.bodySmall)
                    }
                } else if (type == StepType.PLAY_PLAYLIST) {
                    val names = PlaylistStore.names(ctx)
                    if (names.isEmpty()) item { Text("Belum ada playlist. Buat dulu lewat tombol 🎵 di layar utama.") }
                    else item {
                        Text("Pilih playlist", style = MaterialTheme.typography.titleSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            names.forEach { n -> FilterChip(data == n, { data = n }, label = { Text(n) }) }
                        }
                    }
                    item { OutlinedTextField(dur, { dur = it }, label = { Text("Lama diputar (menit)") }, singleLine = true) }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Putar acak", Modifier.weight(1f)); Switch(shuffle, { shuffle = it })
                        }
                    }
                } else {
                    item {
                        OutlinedButton(onClick = { picker = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Aplikasi: " + label.ifBlank { "belum dipilih" })
                        }
                    }
                    if (type == StepType.OPEN_LINK)
                        item { OutlinedTextField(data, { data = it }, label = { Text("Link (https://…)") }, modifier = Modifier.fillMaxWidth()) }
                    if (type == StepType.YOUTUBE_LATEST)
                        item { OutlinedTextField(data, { data = it }, label = { Text("Channel (@handle atau link)") }, modifier = Modifier.fillMaxWidth()) }
                    if (type == StepType.PLAY_MUSIC)
                        item { OutlinedTextField(data, { data = it }, label = { Text("Judul / artis") }, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(dur, { dur = it }, label = { Text("Durasi aktif (menit)") }, singleLine = true) }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if (online) "Online (butuh internet)" else "Offline")
                                Text("Online dilewati otomatis bila tidak ada internet", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(online, { online = it })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onOk(Step(type, text, pkg, label, data.trim(), dur.toIntOrNull()?.coerceAtLeast(1) ?: 10, online, shuffle))
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )

    if (picker) AppPicker(onDismiss = { picker = false }, onPick = { l, p -> label = l; pkg = p; picker = false })
}

@Composable
fun AppPicker(onDismiss: () -> Unit, onPick: (String, String) -> Unit) {
    val ctx = LocalContext.current
    val apps = remember {
        val pm = ctx.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }
    }
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pilih aplikasi") },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, label = { Text("Cari") }, singleLine = true)
                LazyColumn(Modifier.height(320.dp)) {
                    items(apps.filter { it.first.contains(q, ignoreCase = true) }) { (label, pkg) ->
                        Text(label, Modifier.fillMaxWidth().clickable { onPick(label, pkg) }.padding(vertical = 12.dp))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
