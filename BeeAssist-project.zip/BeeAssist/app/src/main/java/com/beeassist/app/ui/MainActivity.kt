package com.beeassist.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.Color
import com.beeassist.app.core.*
import com.beeassist.app.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDb.get(this).dao()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Color(0xFF0D47A1), secondary = Color(0xFFFFB300), tertiary = Color(0xFFFFB300))) {
                var logged by rememberSaveable { mutableStateOf(false) }
                if (!logged) LoginScreen { logged = true } else Home(dao)
            }
        }
    }
}

val DAY_NAMES = listOf("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab")

fun daysText(mask: Int) = when (mask) {
    0b1111111 -> "Setiap hari"
    0 -> "Sekali"
    else -> DAY_NAMES.filterIndexed { i, _ -> (mask shr i) and 1 == 1 }.joinToString(", ")
}

fun runNow(ctx: Context, s: Schedule) = ContextCompat.startForegroundService(
    ctx, Intent(ctx, RunnerService::class.java).putExtra(Scheduler.EXTRA_ID, s.id).putExtra(Scheduler.EXTRA_ITER, 1)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home(dao: ScheduleDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list by dao.observeAll().collectAsState(emptyList())
    var editing by remember { mutableStateOf<Schedule?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    var userName by remember { mutableStateOf(Prefs.userName(ctx)) }
    var assistant by remember { mutableStateOf(Prefs.assistantName(ctx)) }
    var askName by remember { mutableStateOf(Prefs.userName(ctx).isBlank()) }
    val speaker = remember { Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    LaunchedEffect(Unit) {
        speaker.say(
            if (userName.isBlank()) "Halo, saya $assistant siap membantu aktivitas kamu. Siapa nama kamu?"
            else "Halo $userName, saya $assistant siap membantu aktivitas kamu."
        )
    }

    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()

    // Perintah suara di aplikasi: "jalankan <nama jadwal>", "berhenti"
    fun listenOnce() {
        scope.launch {
            toast("Mendengarkan…")
            val text = Voice.listen(ctx, 7000)?.lowercase()
            if (text == null) { toast("Tidak terdengar"); return@launch }
            when {
                "berhenti" in text || "stop" in text ->
                    ctx.startService(Intent(ctx, RunnerService::class.java).setAction(RunnerService.ACTION_STOP))
                else -> {
                    val t = list.firstOrNull { it.name.isNotBlank() && text.contains(it.name.lowercase()) }
                    if (t != null) { toast("Menjalankan ${t.name}"); runNow(ctx, t) } else toast("\"$text\" tidak dikenali")
                }
            }
        }
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listenOnce() else toast("Izin mikrofon ditolak")
    }

    if (showPlaylists) {
        BackHandler { showPlaylists = false }
        PlaylistScreen { showPlaylists = false }
        return
    }
    if (editing != null) {
        BackHandler { editing = null }
        Editor(
            init = editing!!,
            onClose = { editing = null },
            onDelete = { val e = editing!!; scope.launch { Scheduler.cancel(ctx, e.id); dao.delete(e); editing = null } },
            onSave = { s ->
                scope.launch {
                    val id = dao.upsert(s)
                    Scheduler.scheduleNext(ctx, s.copy(id = if (s.id == 0L) id else s.id))
                    editing = null
                }
            }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Bee-Assist") }, actions = {
                TextButton(onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == 0) listenOnce()
                    else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text("🎤") }
                TextButton(onClick = { showPlaylists = true }) { Text("🎵") }
                TextButton(onClick = { showSettings = true }) { Text("⚙") }
            })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                editing = Schedule(
                    name = "", hour = 8, minute = 0,
                    steps = listOf(Step(StepType.SPEAK,
                        text = "Selamat {sapaan} {nama}. Saya {asisten}. Sekarang pukul {jam}. Cuaca {cuaca}, suhu {suhu}, peluang hujan {hujan}. Katakan lanjut untuk memulai."))
                )
            }) { Text("+") }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Card(Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(if (userName.isBlank()) "Halo!" else "Halo, $userName 👋",
                            style = MaterialTheme.typography.titleLarge)
                        Text("Saya $assistant, siap membantu aktivitas kamu.")
                    }
                }
            }
            items(list, key = { it.id }) { s ->
                Card(Modifier.fillMaxWidth(), onClick = { editing = s }) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("%02d:%02d  %s".format(s.hour, s.minute, s.name), style = MaterialTheme.typography.titleMedium)
                                Text("${daysText(s.daysMask)} • ${s.steps.size} langkah • ${s.repeatCount}x",
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = s.enabled, onCheckedChange = { on ->
                                scope.launch {
                                    val n = s.copy(enabled = on); dao.upsert(n)
                                    if (on) Scheduler.scheduleNext(ctx, n) else Scheduler.cancel(ctx, n.id)
                                }
                            })
                        }
                        TextButton(onClick = { runNow(ctx, s) }) { Text("▶ Jalankan sekarang") }
                    }
                }
            }
        }
    }

    if (showSettings) SettingsDialog(onDismiss = {
        showSettings = false; userName = Prefs.userName(ctx); assistant = Prefs.assistantName(ctx)
    })
    if (askName) NameDialog { n ->
        Prefs.setUserName(ctx, n); userName = n; askName = false
        speaker.say("Senang berkenalan, $n. Saya $assistant siap membantu aktivitas kamu.")
    }
}

@SuppressLint("MissingPermission")
private fun lastLocation(ctx: Context): Location? {
    val lm = ctx.getSystemService(LocationManager::class.java)
    return lm.getProviders(true).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
        .maxByOrNull { it.time }
}

@Composable
fun SettingsDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var lat by remember { mutableStateOf(Prefs.lat(ctx).toString()) }
    var lon by remember { mutableStateOf(Prefs.lon(ctx).toString()) }
    var uname by remember { mutableStateOf(Prefs.userName(ctx)) }
    var aname by remember { mutableStateOf(Prefs.assistantName(ctx)) }

    fun useMyLocation() {
        val l = lastLocation(ctx)
        if (l != null) { lat = "%.4f".format(l.latitude); lon = "%.4f".format(l.longitude) }
        else Toast.makeText(ctx, "Lokasi belum tersedia, buka Google Maps sebentar", Toast.LENGTH_LONG).show()
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_COARSE_LOCATION] == true) useMyLocation()
    }
    fun open(a: String) = ctx.startActivity(Intent(a, Uri.parse("package:${ctx.packageName}")))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pengaturan") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Profil", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(uname, { uname = it }, label = { Text("Nama pengguna") }, singleLine = true)
                OutlinedTextField(aname, { aname = it }, label = { Text("Nama asisten") }, singleLine = true)
                HorizontalDivider()
                Text("Lokasi cuaca", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(lat, { lat = it }, label = { Text("Latitude") }, singleLine = true)
                OutlinedTextField(lon, { lon = it }, label = { Text("Longitude") }, singleLine = true)
                OutlinedButton(onClick = {
                    val p = mutableListOf(Manifest.permission.ACCESS_COARSE_LOCATION)
                    perms.launch(p.toTypedArray())
                }) { Text("Pakai lokasi saya") }
                HorizontalDivider()
                Text("Izin", style = MaterialTheme.typography.titleSmall)
                OutlinedButton(onClick = {
                    val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                    if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
                    perms.launch(p.toTypedArray())
                }) { Text("Mikrofon, kamera & notifikasi") }
                OutlinedButton(onClick = { open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) }) { Text("Tampil di atas aplikasi lain") }
                OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }) { Text("Pengaturan kunci layar") }
                OutlinedButton(onClick = { open(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS) }) { Text("Abaikan optimasi baterai") }
                if (Build.VERSION.SDK_INT >= 31) {
                    val am = ctx.getSystemService(AlarmManager::class.java)
                    if (!am.canScheduleExactAlarms())
                        OutlinedButton(onClick = { open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM) }) { Text("Izinkan alarm presisi") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { Prefs.setLocation(ctx, lat, lon); Prefs.setNames(ctx, uname.trim(), aname.trim()); onDismiss() }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup") } }
    )
}
