package com.beeassist.app.core

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun lat(c: Context) = sp(c).getString("lat", "-6.2")?.toDoubleOrNull() ?: -6.2   // default Jakarta
    fun lon(c: Context) = sp(c).getString("lon", "106.8")?.toDoubleOrNull() ?: 106.8
    fun setLocation(c: Context, lat: String, lon: String) =
        sp(c).edit().putString("lat", lat).putString("lon", lon).apply()

    fun userName(c: Context) = sp(c).getString("user", "") ?: ""
    fun assistantName(c: Context) = sp(c).getString("assistant", "Honey Bee")?.ifBlank { "Honey Bee" } ?: "Honey Bee"
    fun setUserName(c: Context, n: String) = sp(c).edit().putString("user", n).apply()
    fun setNames(c: Context, user: String, assistant: String) =
        sp(c).edit().putString("user", user).putString("assistant", assistant).apply()
}
