package com.beeassist.app.core

import android.content.*
import androidx.core.content.ContextCompat
import com.beeassist.app.data.AppDb
import kotlinx.coroutines.*

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val svc = Intent(ctx, RunnerService::class.java)
            .putExtra(Scheduler.EXTRA_ID, intent.getLongExtra(Scheduler.EXTRA_ID, -1))
            .putExtra(Scheduler.EXTRA_ITER, intent.getIntExtra(Scheduler.EXTRA_ITER, 1))
        ContextCompat.startForegroundService(ctx, svc)
    }
}

/** Jadwalkan ulang semua alarm setelah HP restart. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            AppDb.get(ctx).dao().all().forEach { Scheduler.scheduleNext(ctx, it) }
            pending.finish()
        }
    }
}
