package com.beeassist.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.beeassist.app.R
import com.beeassist.app.core.Prefs
import java.security.MessageDigest

// Disimpan sebagai hash SHA-256 (bukan teks asli). Ini pengaman dasar, bukan keamanan tingkat tinggi.
private const val USER_HASH = "593b0a983250809aedfe2051d8ac9c8503a2b99f6a7a0617b896aed18f4f08c8"
private const val PASS_HASH = "596334a05ebe86ce9e785a9fc311be59ed0ee1262754b573b997f1143a771127"

private fun sha(s: String) =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

@Composable
fun LoginScreen(onSuccess: () -> Unit) {
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp).imePadding(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.bee_logo), contentDescription = "Bee-Assist", modifier = Modifier.size(180.dp))
        Spacer(Modifier.height(12.dp))
        Text("Masuk ke Bee-Assist", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(u, { u = it; err = false }, label = { Text("Login") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(p, { p = it; err = false }, label = { Text("Password") }, singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "Sembunyi" else "Lihat") } },
            modifier = Modifier.fillMaxWidth())
        if (err) Text("Login atau password salah", color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { if (sha(u.trim()) == USER_HASH && sha(p) == PASS_HASH) onSuccess() else err = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Masuk") }
    }
}

@Composable
fun NameDialog(onSave: (String) -> Unit) {
    var n by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Siapa nama kamu?") },
        text = {
            OutlinedTextField(n, { n = it }, label = { Text("Nama pengguna") }, singleLine = true)
        },
        confirmButton = { TextButton(enabled = n.isNotBlank(), onClick = { onSave(n.trim()) }) { Text("Simpan") } }
    )
}
