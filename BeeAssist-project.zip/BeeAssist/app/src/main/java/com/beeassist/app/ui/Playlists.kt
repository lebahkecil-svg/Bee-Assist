package com.beeassist.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.beeassist.app.core.PlaylistStore
import com.beeassist.app.core.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var names by remember { mutableStateOf(PlaylistStore.names(ctx)) }
    var editing by remember { mutableStateOf<String?>(null) }   // "" = playlist baru

    if (editing != null) {
        BackHandler { editing = null }
        PlaylistEditor(editing!!) { names = PlaylistStore.names(ctx); editing = null }
        return
    }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Playlist") },
                navigationIcon = { TextButton(onClick = onClose) { Text("Kembali") } })
        },
        floatingActionButton = { FloatingActionButton(onClick = { editing = "" }) { Text("+") } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (names.isEmpty()) item { Text("Belum ada playlist. Tekan + untuk membuat dari lagu di HP kamu.") }
            items(names) { n ->
                Card(onClick = { editing = n }, modifier = Modifier.fillMaxWidth()) {
                    Text("🎶 $n  •  ${PlaylistStore.get(ctx, n).size} lagu", Modifier.padding(14.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistEditor(original: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(original) }
    val chosen = remember { mutableStateListOf<Track>().also { it.addAll(PlaylistStore.get(ctx, original)) } }
    var songs by remember { mutableStateOf<List<Track>?>(null) }
    var q by remember { mutableStateOf("") }
    var denied by remember { mutableStateOf(false) }
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
               else Manifest.permission.READ_EXTERNAL_STORAGE

    fun load() { scope.launch { songs = withContext(Dispatchers.IO) { PlaylistStore.loadSongs(ctx) } } }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) load() else denied = true
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, perm) == 0) load() else launcher.launch(perm)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(if (original.isBlank()) "Playlist baru" else "Ubah playlist") },
                navigationIcon = { TextButton(onClick = onDone) { Batal() } })
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp).navigationBarsPadding(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (original.isNotBlank())
                    OutlinedButton(onClick = { PlaylistStore.delete(ctx, original); onDone() }) { Text("Hapus") }
                Button(
                    enabled = name.isNotBlank() && chosen.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (original.isNotBlank() && original != name.trim()) PlaylistStore.delete(ctx, original)
                        PlaylistStore.save(ctx, name.trim(), chosen.toList()); onDone()
                    }
                ) { Text("Simpan (${chosen.size} lagu)") }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Nama playlist") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(q, { q = it }, label = { Text("Cari lagu") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            when {
                denied -> Text("Izin membaca audio ditolak. Aktifkan di Pengaturan HP → Aplikasi → Bee-Assist → Izin.")
                songs == null -> Text("Memuat lagu…")
                songs!!.isEmpty() -> Text("Tidak ada lagu ditemukan di HP.")
                else -> LazyColumn {
                    items(songs!!.filter { it.title.contains(q, ignoreCase = true) }, key = { it.uri }) { t ->
                        val on = chosen.any { it.uri == t.uri }
                        Row(
                            Modifier.fillMaxWidth().clickable { if (on) chosen.removeAll { it.uri == t.uri } else chosen.add(t) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = on, onCheckedChange = null)
                            Spacer(Modifier.width(8.dp))
                            Text(t.title, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun Batal() = Text("Batal")
