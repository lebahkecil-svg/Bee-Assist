package com.beeassist.app.core

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.beeassist.app.data.Schedule
import java.util.Calendar

object Scheduler {
    const val EXTRA_ID = "id"
    const val EXTRA_ITER = "iter"

    /** Waktu pemicu berikutnya sesuai jam & hari; -1 jika tidak ada hari dipilih. */
    fun nextTrigger(s: Schedule, now: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, s.hour); set(Calendar.MINUTE, s.minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        repeat(8) {
            val dow = cal.get(Calendar.DAY_OF_WEEK) // 1=Minggu..7=Sabtu
            if (cal.timeInMillis > now && ((s.daysMask shr (dow - 1)) and 1) == 1) return cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return -1
    }

    fun scheduleNext(ctx: Context, s: Schedule) {
        if (!s.enabled) { cancel(ctx, s.id); return }
        val t = nextTrigger(s)
        if (t > 0) setAlarm(ctx, s.id, 1, t)
    }

    fun scheduleRepeat(ctx: Context, s: Schedule, iteration: Int) =
        setAlarm(ctx, s.id, iteration, System.currentTimeMillis() + s.repeatIntervalMin * 60_000L)

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, id, 1))
    }

    private fun setAlarm(ctx: Context, id: Long, iter: Int, at: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, id, iter)
        if (android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) // fallback kurang presisi
    }

    private fun pending(ctx: Context, id: Long, iter: Int) = PendingIntent.getBroadcast(
        ctx, id.toInt(),
        Intent(ctx, AlarmReceiver::class.java).putExtra(EXTRA_ID, id).putExtra(EXTRA_ITER, iter),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
