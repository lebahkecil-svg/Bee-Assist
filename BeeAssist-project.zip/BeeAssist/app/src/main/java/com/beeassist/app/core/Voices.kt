package com.beeassist.app.core

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * 6 pilihan suara: 3 cewek + 3 cowok.
 * Mesin Google TTS bahasa Indonesia punya 4 suara asli (ida, idc = cewek; idb, idd = cowok).
 * Pilihan ke-3 tiap gender memakai suara yang sama dengan nada/kecepatan berbeda.
 */
enum class VoiceProfile(val label: String, val key: String, val pitch: Float, val rate: Float) {
    CEWEK_1("Cewek 1", "-ida-", 1.0f, 1.0f),
    CEWEK_2("Cewek 2", "-idc-", 1.0f, 1.0f),
    CEWEK_3("Cewek 3 (ceria)", "-ida-", 1.2f, 1.05f),
    COWOK_1("Cowok 1", "-idb-", 1.0f, 1.0f),
    COWOK_2("Cowok 2", "-idd-", 1.0f, 1.0f),
    COWOK_3("Cowok 3 (berat)", "-idb-", 0.8f, 0.95f),
}

object Voices {
    fun apply(ctx: Context, tts: TextToSpeech) {
        val p = Prefs.voiceProfile(ctx)
        tts.language = Locale("id", "ID")          // set bahasa dulu, baru suara
        val ids = runCatching {
            tts.voices.orEmpty().filter { it.locale.language == "in" || it.locale.language == "id" }
        }.getOrDefault(emptyList())
        val pick = ids.filter { it.name.contains(p.key) }.minByOrNull { if (it.isNetworkConnectionRequired) 1 else 0 }
            ?: ids.sortedBy { it.name }.let { if (it.isEmpty()) null else it[p.ordinal % it.size] }
        if (pick != null) tts.voice = pick
        tts.setPitch(p.pitch)
        tts.setSpeechRate(p.rate)
    }
}
