package com.beeassist.app.ui

import android.content.Context
import android.speech.tts.TextToSpeech
import com.beeassist.app.core.Voices

/** TTS sederhana untuk salam di layar aplikasi. */
class Speaker(private val ctx: Context) {
    private var ready = false
    private var pending: String? = null
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.let { Voices.apply(ctx.applicationContext, it) }
                ready = true
                pending?.let { say(it); pending = null }
            }
        }
    }

    fun say(text: String) {
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ui") else pending = text
    }

    fun reapply() { tts?.let { Voices.apply(ctx.applicationContext, it) } }

    fun shutdown() { tts?.shutdown(); tts = null }
}
