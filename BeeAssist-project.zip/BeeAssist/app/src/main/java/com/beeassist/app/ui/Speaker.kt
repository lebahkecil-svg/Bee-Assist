package com.beeassist.app.ui

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** TTS sederhana untuk salam di layar aplikasi. */
class Speaker(ctx: Context) {
    private var ready = false
    private var pending: String? = null
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("id", "ID")
                ready = true
                pending?.let { say(it); pending = null }
            }
        }
    }

    fun say(text: String) {
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ui") else pending = text
    }

    fun shutdown() { tts?.shutdown(); tts = null }
}
