package com.beeassist.app.core

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.MediaStore
import android.view.KeyEvent
import com.beeassist.app.data.Step
import com.beeassist.app.data.StepType

object Net {
    fun isOnline(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
               caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}

/** Membuka, memutar, dan menghentikan aplikasi lain. */
object AppController {

    fun launch(ctx: Context, st: Step) {
        val intent: Intent? = when (st.type) {
            StepType.OPEN_APP -> ctx.packageManager.getLaunchIntentForPackage(st.packageName)
            StepType.OPEN_LINK -> Intent(Intent.ACTION_VIEW, Uri.parse(st.data)).apply {
                if (st.packageName.isNotBlank()) setPackage(st.packageName)
            }
            StepType.PLAY_MUSIC -> Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                putExtra(SearchManager.QUERY, st.data)
                if (st.packageName.isNotBlank()) setPackage(st.packageName)
            }
            StepType.SPEAK, StepType.YOUTUBE_LATEST, StepType.PLAY_PLAYLIST -> null
        }
        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        // Butuh izin "Tampil di atas aplikasi lain" agar bisa dibuka dari background
        runCatching { intent?.let { ctx.startActivity(it) } }
    }

    fun stop(ctx: Context, st: Step) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE))

        // Tutup paksa (butuh root; tanpa root ganti dengan Shizuku)
        if (st.packageName.isNotBlank())
            runCatching { Runtime.getRuntime().exec(arrayOf("su", "-c", "am force-stop ${st.packageName}")) }

        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
