package com.beeassist.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

enum class StepType { SPEAK, OPEN_APP, OPEN_LINK, PLAY_MUSIC, YOUTUBE_LATEST, PLAY_PLAYLIST }

/** Satu langkah dalam rangkaian: ucapan TTS ATAU aksi aplikasi. */
data class Step(
    val type: StepType,
    val text: String = "",          // SPEAK: teks (bisa pakai {jam} {cuaca} dst.)
    val packageName: String = "",   // aplikasi target
    val appLabel: String = "",
    val data: String = "",          // OPEN_LINK: URL / PLAY_MUSIC: judul atau artis
    val durationMin: Int = 10,      // berapa lama aplikasi aktif
    val online: Boolean = false,
    val shuffle: Boolean = false,    // PLAY_PLAYLIST: putar acak    // true = butuh internet; kalau offline-an, langkah dilewati
)

@Entity
data class Schedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val hour: Int,
    val minute: Int,
    val daysMask: Int = 0b1111111,      // bit0=Minggu ... bit6=Sabtu
    val steps: List<Step> = emptyList(),
    val repeatCount: Int = 1,           // seluruh rangkaian diulang berapa kali
    val repeatIntervalMin: Int = 5,
    val voiceControl: Boolean = true,   // dengarkan perintah suara setelah tiap ucapan
    val enabled: Boolean = true,
)

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM Schedule ORDER BY hour, minute")
    fun observeAll(): Flow<List<Schedule>>
    @Query("SELECT * FROM Schedule") suspend fun all(): List<Schedule>
    @Query("SELECT * FROM Schedule WHERE id = :id") suspend fun get(id: Long): Schedule?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(s: Schedule): Long
    @Delete suspend fun delete(s: Schedule)
}

class Converters {
    @TypeConverter fun fromSteps(l: List<Step>): String = JSONArray().also { arr ->
        l.forEach {
            arr.put(JSONObject().put("type", it.type.name).put("text", it.text)
                .put("pkg", it.packageName).put("label", it.appLabel).put("data", it.data)
                .put("dur", it.durationMin).put("online", it.online).put("shuffle", it.shuffle))
        }
    }.toString()

    @TypeConverter fun toSteps(s: String): List<Step> {
        val a = JSONArray(s)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Step(StepType.valueOf(o.getString("type")), o.optString("text"), o.optString("pkg"),
                o.optString("label"), o.optString("data"), o.optInt("dur", 10), o.optBoolean("online"), o.optBoolean("shuffle"))
        }
    }
}

@Database(entities = [Schedule::class], version = 2, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): ScheduleDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: android.content.Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "sched.db")
                .fallbackToDestructiveMigration().build().also { inst = it }
        }
    }
}
