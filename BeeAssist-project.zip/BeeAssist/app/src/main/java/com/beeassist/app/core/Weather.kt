package com.beeassist.app.core

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

data class Weather(
    val desc: String, val temp: Int, val humidity: Int, val wind: Int,
    val rainProb: Int, val tMax: Int, val tMin: Int,
)

/** Cuaca dari Open-Meteo (gratis, tanpa API key). */
object WeatherClient {
    private val tokens = listOf("{cuaca}", "{suhu}", "{suhumax}", "{suhumin}", "{hujan}", "{angin}", "{lembab}")
    fun needs(text: String) = tokens.any { text.contains(it) }

    suspend fun fetch(ctx: Context): Weather? = withContext(Dispatchers.IO) {
        runCatching {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=${Prefs.lat(ctx)}&longitude=${Prefs.lon(ctx)}" +
                "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=1"
            )
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
            Weather(
                describe(cur.getInt("weather_code")),
                cur.getDouble("temperature_2m").roundToInt(),
                cur.getInt("relative_humidity_2m"),
                cur.getDouble("wind_speed_10m").roundToInt(),
                d.getJSONArray("precipitation_probability_max").optInt(0),
                d.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                d.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
            )
        }.getOrNull()
    }

    private fun describe(code: Int) = when (code) {
        0 -> "cerah"; 1, 2 -> "cerah berawan"; 3 -> "berawan"; 45, 48 -> "berkabut"
        51, 53, 55, 56, 57 -> "gerimis"; 61, 63 -> "hujan ringan"; 65 -> "hujan lebat"
        66, 67 -> "hujan beku"; in 71..77 -> "salju"; 80, 81 -> "hujan lokal"
        82 -> "hujan sangat lebat"; 95 -> "badai petir"; 96, 99 -> "badai petir dan es"
        else -> "tidak diketahui"
    }

    /** Mengganti semua token: {jam} {hari} {sapaan} + token cuaca. */
    fun fill(ctx: Context, text: String, w: Weather?): String {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val sapaan = when (h) { in 4..10 -> "pagi"; in 11..14 -> "siang"; in 15..17 -> "sore"; else -> "malam" }
        val na = "tidak diketahui"
        return text
            .replace("{jam}", SimpleDateFormat("HH.mm", Locale("id")).format(cal.time))
            .replace("{hari}", SimpleDateFormat("EEEE", Locale("id")).format(cal.time))
            .replace("{sapaan}", sapaan)
            .replace("{nama}", Prefs.userName(ctx).ifBlank { "teman" })
            .replace("{asisten}", Prefs.assistantName(ctx))
            .replace("{cuaca}", w?.desc ?: "data cuaca tidak tersedia")
            .replace("{suhumax}", w?.let { "${it.tMax} derajat" } ?: na)
            .replace("{suhumin}", w?.let { "${it.tMin} derajat" } ?: na)
            .replace("{suhu}", w?.let { "${it.temp} derajat" } ?: na)
            .replace("{hujan}", w?.let { "${it.rainProb} persen" } ?: na)
            .replace("{angin}", w?.let { "${it.wind} kilometer per jam" } ?: na)
            .replace("{lembab}", w?.let { "${it.humidity} persen" } ?: na)
    }
}
