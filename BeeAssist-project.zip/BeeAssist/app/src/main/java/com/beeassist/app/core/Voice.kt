package com.beeassist.app.core

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

enum class Cmd { NEXT, SKIP, REPEAT, STOP, NONE }

/** Pengenalan perintah suara (bahasa Indonesia, utamakan offline). */
object Voice {

    fun parse(text: String?): Cmd {
        val w = text?.lowercase()?.split(" ", ",", ".")?.filter { it.isNotBlank() }?.toSet() ?: return Cmd.NONE
        return when {
            w.any { it in setOf("berhenti", "stop", "selesai", "cukup", "batal") } -> Cmd.STOP
            w.any { it in setOf("lewati", "lewat", "skip", "loncat") } -> Cmd.SKIP
            w.any { it in setOf("ulangi", "ulang", "lagi") } -> Cmd.REPEAT
            w.any { it in setOf("lanjut", "lanjutkan", "ya", "oke", "ok", "siap", "mulai") } -> Cmd.NEXT
            else -> Cmd.NONE
        }
    }

    /** Mendengar satu ucapan. Return null jika tidak ada izin / tidak terdengar / timeout. */
    suspend fun listen(ctx: Context, timeoutMs: Long = 6000): String? = withContext(Dispatchers.Main) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return@withContext null
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) return@withContext null

        withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<String?> { cont ->
                val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
                var closed = false
                fun close() {
                    if (closed) return
                    closed = true
                    Handler(Looper.getMainLooper()).post { sr.destroy() }
                }
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(b: Bundle?) {
                        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (cont.isActive) cont.resume(t); close()
                    }
                    override fun onError(error: Int) { if (cont.isActive) cont.resume(null); close() }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(b: Bundle?) {}
                    override fun onEvent(t: Int, b: Bundle?) {}
                })
                cont.invokeOnCancellation { close() }
                sr.startListening(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                        .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                        .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                )
            }
        }
    }
}
