package com.beeassist.app.core

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

data class Track(val uri: String, val title: String)

/** Playlist buatan sendiri (disimpan lokal) + pembaca lagu dari penyimpanan HP. */
object PlaylistStore {
    private fun sp(c: Context) = c.getSharedPreferences("playlists", Context.MODE_PRIVATE)
    private fun all(c: Context) = JSONObject(sp(c).getString("all", "{}") ?: "{}")

    fun names(c: Context): List<String> = all(c).keys().asSequence().toList().sortedBy { it.lowercase() }

    fun get(c: Context, name: String): List<Track> {
        val a = all(c).optJSONArray(name) ?: return emptyList()
        return List(a.length()) { val o = a.getJSONObject(it); Track(o.getString("u"), o.optString("t")) }
    }

    fun save(c: Context, name: String, tracks: List<Track>) {
        val arr = JSONArray().also { a -> tracks.forEach { a.put(JSONObject().put("u", it.uri).put("t", it.title)) } }
        sp(c).edit().putString("all", all(c).put(name, arr).toString()).apply()
    }

    fun delete(c: Context, name: String) {
        val o = all(c); o.remove(name)
        sp(c).edit().putString("all", o.toString()).apply()
    }

    /** Semua lagu di HP (butuh izin baca audio). */
    fun loadSongs(c: Context): List<Track> {
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val out = mutableListOf<Track>()
        c.contentResolver.query(
            base,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
            "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
        )?.use { cur ->
            while (cur.moveToNext()) {
                val artist = cur.getString(2)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                out += Track(
                    ContentUris.withAppendedId(base, cur.getLong(0)).toString(),
                    cur.getString(1) + (artist?.let { " – $it" } ?: "")
                )
            }
        }
        return out
    }
}
